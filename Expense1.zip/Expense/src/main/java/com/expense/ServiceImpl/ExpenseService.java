package com.expense.ServiceImpl;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.expense.Entity.Expense;
import com.expense.Repo.ExpenseRepository;
/*
 * 2. **API Endpoints**
• - `POST /expenses` → Add a new expense.
• - `GET /expenses` → Retrieve all expenses.
• - `GET /expenses/{id}` → Retrieve a specific expense by ID.
• - `GET /expenses/summary?month=MM&year;=YYYY` → Return the **total expenses** for the
given month and year.
 * 
 * 
 * 
 * */
@Service
public class ExpenseService {

	@Autowired
	private ExpenseRepository expenseRepo;
	
	
	public Expense addExp(Expense expense) {
		
		return expenseRepo.save(expense);
	}
	
	public List<Expense> getAllExpense(){
		
		return expenseRepo.findAll();
	}
	
	
	public Expense getExpenseByid(Long id) {
		
		return expenseRepo.findById(id).orElseThrow(()->new RuntimeException("Id not found"));
	}
	public double getMonthAndYearExpenses(int month,int year) {
		LocalDate startDate=LocalDate.of(year, month, 1);
		LocalDate endDate=startDate.withDayOfMonth(startDate.lengthOfMonth());
		
		List<Expense> expense=expenseRepo.findByDateBetween(startDate, endDate);
		
		return expense.stream().mapToDouble(Expense::getAmount).sum();

		
	}
	
	
}
