package com.expense.Entity;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;



/*1. **Entity: Expense**
• - `id` (auto-generated)
• - `title` (string)
• - `amount` (double)
• - `date` (LocalDate)

*3. **Validation**
• - `title` must not be empty.
• - `amount` must be greater than 0.
*
*
*/
@Entity
public class Expense {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	@NotEmpty(message="Title not be empty")
	private String title;
	
	@Min(value =0,message="amount must be greater than 0")
	private double amount;
	
	private LocalDate date;

	public Expense(long id, @NotEmpty(message = "Title not be empty") String title,
			@Min(value = 0, message = "amount must be greater than 0") double amount, LocalDate date) {
		super();
		this.id = id;
		this.title = title;
		this.amount = amount;
		this.date = date;
	}

	public Expense() {
		super();
		// TODO Auto-generated constructor stub
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}
	
	
}
