package com.expense.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.service.annotation.GetExchange;

import com.expense.Entity.Expense;
import com.expense.ServiceImpl.ExpenseService;

import jakarta.annotation.PostConstruct;
import jakarta.validation.Valid;


/*
 * 2. **API Endpoints**
• - `POST /expenses` → Add a new expense.
• - `GET /expenses` → Retrieve all expenses.
• - `GET /expenses/{id}` → Retrieve a specific expense by ID.
• - `GET /expenses/summary?month=MM&year;=YYYY` → Return the **total expenses** for the
given month and year.
 * 
 * 
 * 
 * */
@RestController
@RequestMapping("/expenses")
public class ExpenseController {
	
	@Autowired
	private ExpenseService expenseser;

	@PostMapping("/new/")
	public Expense addexp(@Valid @RequestBody Expense expense) {
		return expenseser.addExp(expense);
	}
	
	@GetMapping("/getall/")
	public List<Expense> getallExpenses(){
		
		return expenseser.getAllExpense();
		
	}
	
	@GetMapping("/{id}/")
	public Expense getExpenseById(@PathVariable Long id) {
		Expense ex=expenseser.getExpenseByid(id);
		if(ex==null) {
			throw new RuntimeException("id not available");
		}
		return ex;
	}
	
	@GetMapping("/summary")
	public Map<String,Object> getexpenseSummary(@RequestParam int month,@RequestParam int year){
		
		double total=expenseser.getMonthAndYearExpenses(month, year);
		
		Map<String,Object> response=new HashMap<>();
		response.put("month", month);
		response.put("year", year);

		response.put("TotalExpenses", total);
		
		return response;

		
	}
	
	
}
